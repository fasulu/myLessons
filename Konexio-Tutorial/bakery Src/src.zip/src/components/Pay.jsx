import React, { Component } from 'react'

class Pay extends Component{
    render(){
      return(
        <div>
            <h1>Pay</h1>
        </div>
      )
    }
}
export default Pay;